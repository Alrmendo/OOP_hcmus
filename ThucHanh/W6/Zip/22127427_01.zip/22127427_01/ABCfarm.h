#ifndef ABCFARM_H
#define ABCFARM_H

#include <iostream>
#include <vector>
using namespace std;

class Animal 
{
protected:
    int identifier;
    double weight;
    double age;

public:
    Animal();
    Animal(int id, double w, double a);
    Animal(const Animal& other);
    int getIdentifier() const;
    double getWeight() const;
    double getAge() const;
    void setWeight(double w);
    void setAge(double a);
    bool isValidWeight() const;
    bool isValidAge() const;
    virtual std::string getType() const = 0;
    std::string toString() const;
    virtual ~Animal() {}
};

class DairyCow : public Animal 
{
public:
    DairyCow();
    DairyCow(int id, double w, double a);
    DairyCow(const DairyCow& other);
    std::string getType() const;
};

class Goat : public Animal 
{
public:
    Goat();
    Goat(int id, double w, double a);
    Goat(const Goat& other);
    std::string getType() const;
};

class ABCFarm 
{
private:
    std::vector<Animal*> animals;

public:
    void Input();
    void Output();
    void OutputByAge(int min, int max);
    ~ABCFarm();
};

#endif // ABCFARM_H
